tuple=("Rose","Lily","Lotus","Sunflower","Merigold")
print(len(tuple))

#update items 
t=list(tuple)
t[4]="Jasmine"
# print(t)

#add items
t.append("Merigold")
print(t)