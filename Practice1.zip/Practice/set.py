#Create a Set
s={3,5,4,6,7,5,9,4,2,7,7,3,7,4}
print(s)

# Note: Duplicates not allowed
print(len(s))

#add() method add items to set
s.add("h")
print(s)

#add set to existing set
s1={"e","l","l","o"}
s.update(s1)
print(s)

#add list to set
myls=[9.7,3.4,2.1,1.1]
s.update(myls)
print(s)

#union set s and s1
# ns=s.union(s1)
# print(ns)

#intersection set3 and set4
s3={34,53,6,2,3,82,9,6,3}
s4={34,53,82,6,9,2,3,4}
ns=s3.intersection(s4)
print(ns)