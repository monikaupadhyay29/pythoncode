from inheritance import calculation3

obj=calculation3()
print(obj.addition(5,6))

print(obj.simple_interest(50,4,5))



from function import myfun

d=myfun(3,2)
print(d)